WEBSITE TÌNH YÊU 20/10 — HƯỚNG DẪN NHANH

1. Mở index.html bằng Chrome để xem thử.
2. Tùy chỉnh nhanh: mở mục “Tùy chỉnh nhanh nội dung” ở cuối trang.
   Lưu ý: thay đổi nhanh chỉ có trên phiên đang mở, không tự lưu vào website đã đăng.
3. Thay ảnh: bấm vào ảnh trong album để xem ảnh trên thiết bị của bạn. Để khách truy cập đều thấy ảnh đã chọn, cần thay URL ảnh trong index.html hoặc thêm ảnh vào cùng thư mục và sửa src, ví dụ:
   src="anh-cua-hai-ban.jpg"
   Sau đó tải lại cả index.html và ảnh lên dịch vụ lưu trữ.
4. Đưa website lên mạng miễn phí:
   - Có thể dùng GitHub Pages: tạo repository mới, tải index.html (và ảnh nếu có) lên, vào Settings > Pages, chọn nhánh main và thư mục root rồi lưu.
   - Hoặc dùng dịch vụ lưu trữ tĩnh miễn phí có hỗ trợ kéo-thả thư mục. Hãy kiểm tra điều kiện miễn phí hiện tại của dịch vụ trước khi dùng.
5. Sau khi xuất bản, mở link trên điện thoại để kiểm tra trước khi gửi.

LƯU Ý RIÊNG TƯ:
- Chỉ dùng ảnh mà cả hai bạn đều thoải mái chia sẻ.
- Nếu website công khai, bất kỳ ai có link cũng có thể xem nội dung và ảnh.
- Trang này không tự phát nhạc và không gửi/lưu dữ liệu cá nhân lên máy chủ.
